// CS1300 Fall 2019
// Author: Peter Jakubczak
// Recitation: 104 Pasricha
// Homework 2 #1

#include <iostream>
using namespace std;

/**
 * Algorithm : that displays Hello, World!
 *  1. Create a output Hello, World!
 * Input : None
 * Output : Hello, World!
 * Return : None
 **/
 
int main(){
    cout << "Hello, World!" << endl;
}