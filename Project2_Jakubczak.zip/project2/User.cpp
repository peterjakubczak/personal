//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Homework 7 - Problem 1


/**
 * Algorithim: Creates user function
   1. Creates each individual function for user class
 * Input: Strings, ints, array
 * Output: None
 * Return: Depends per function
*/



#include "User.h"
#include <string>
using namespace std;
#include <cmath>
#include <iostream>

User :: User(){
    string username = ""; //set variable to empty string
    int numRatings = 0;
   // int ratings[] = 0;
   int i = 0;
   while (i < size){
       ratings[i] = 0;
       i++;
   }
    
}

User :: User(string username1, int array[], int numRatings1){
    if(numRatings1 > size){ //num ratings cant be bigger than size
        numRatings1 = size;
    }
    username = username1;
    int k = 0;
    for(k; k < numRatings1; k++){
        ratings[k] = array[k];
    }
    int f = numRatings1;
    for(f; f < size; f++){
        ratings[f] = 0;
    }
    numRatings = numRatings1;
}

string User :: getUsername(){
    return username;
}

int User :: getRatingAt(int index){
    if((index < size) && (index >= 0)){
        return ratings[index]; //return rating at index
    }
    else{
        return -1;
    }
}

void User :: setUsername(string user){
    username = user; //assign username value of input string
}

bool User :: setRatingAt(int index, int value){
    if ((index < size) && ((value >= 0) && (value <= 5))){
        ratings[index] = value; //set rating to value at right index
        return true;
    }
    else{
        return false;
    }
}
int User :: getNumRatings(){
    return numRatings;
}
void User :: setNumRatings(int input){
    numRatings = input; //assign numrating to input
}
int User :: getSize(){
    return size;
}