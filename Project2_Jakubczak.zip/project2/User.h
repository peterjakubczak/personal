//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Homework 7 - Problem 1


/**
 * Algorithim: Creates User class
  * 1. Set up public member functions
 * 2. Set up private member functions
 * Input: Strings, int, array 
 * Output: None
 * Return: None
*/



#include <string>
using namespace std;
#ifndef USER_H
#define USER_H

class User{
     private: //private variables
    string username; 
    int ratings[50];
    int numRatings;
    const int size = 50;
    
    public: //sets up functions
    User();
    User(string username1, int array[], int numRatings1);
    string getUsername();
    void setUsername(string user);
    int getRatingAt(int index);
    bool setRatingAt(int index,int value);
    int getNumRatings();
    void setNumRatings(int input);
    int getSize();
};

#endif