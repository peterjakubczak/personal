//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Project 1 - Problem 7
#include <iostream>
#include <string>
using namespace std;

/**
 * Algorithim: 
 * 1. 
 * 2.
 * 3. 
 * Input: Two String
 * Output: Nothing
 * Return: Matches
*/