//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Project 1 - Problem 3
#include <iostream>
#include <string>
using namespace std;

/**
 * Algorithim: that creates a highscore for the Zootopia police department
 * 1. Void function that gives user options
 * 2. While loop that calculates hire score for certain animals
 * 3. If user chooses 4, the game quits (if statement)
 * 4. While loop causes menu to repeat until user quits
 * Input: Doubles
 * Output: The hire score
 * Return: None
*/
	 void printMenu()
	 { //gives user multiple options
	cout<<"Select a numerical option:"<<endl;
	cout<<"=== menu ==="<<endl;
	cout<<"1. Fox"<<endl;
	cout<<"2. Bunny"<<endl;
	cout<<"3. Sloth"<<endl;
	cout<<"4. Quit"<<endl;
    }


int main()
{

	printMenu();
	double agility = 0.0; //declares agility
	double strength = 0.0; //declares strength
	double speed = 0.0; //declares speed
	int menuChoice;
	cin >> menuChoice;
	while(menuChoice != 4)
	{
		if (menuChoice == 1) //fox
		{
		cout << "Enter agility:" << endl;
		cin >> agility;
		cout << "Enter strength:" << endl;
		cin >> strength;
		speed = 0.0;
		double hireScore = 1.8*agility + 2.16*strength; //calculates score, no speed because 0.0
		cout << "Hire Score: " << hireScore << endl;
		}
		else if (menuChoice == 2){ //bunny
		cout << "Enter agility:" << endl;
		cin >> agility;
		cout << "Enter speed:"<< endl;
		cin >> speed;
		strength = 0.0;
		double hireScore = 1.8*agility + 3.24*speed;
		cout << "Hire Score: " << hireScore << endl;
		} 
		else if (menuChoice == 3){ //sloth
		cout << "Enter strength:" << endl;
		cin >> strength;
		cout << "Enter speed:" << endl;
		cin >> speed;
		agility = 0.0;
		double hireScore = 3.24*speed + 2.16*strength;
		cout << "Hire Score: " << hireScore << endl;
		}
			printMenu();
			cin >> menuChoice;
	}
   if (menuChoice == 4){
   	
   }
  return 0;
}