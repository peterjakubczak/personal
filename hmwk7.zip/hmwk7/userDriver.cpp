
#include "User.h"
#include <string>
using namespace std;
#include <cmath>
#include <iostream>

int main(){
    User u1 = User();
int nRating = 45;
u1.setNumRatings(nRating);
int rating = 3;
int idx = 0;
cout << "set/get setRatingAt(" << idx << "," << rating << ") [numRating=" << nRating  << "]" << endl;
cout << "Setting rating at " << idx << " to " << rating << endl;
string ratingset = u1.setRatingAt(idx,rating) ? "true": "false";
cout << "setRatingAt(" << idx << "," << rating << ") returned: " << ratingset << endl;
cout << "getRatingAt(" << idx << ") returned: " << u1.getRatingAt(idx) << endl;


int testRate[] = {3,1,4,2,1,3,5,0,3,4,0,4,0,3,4,1,4,5,1,5,0,3,0,4,3,3,0,2,1,0,0,3,2,1,2,1,4,2,2,5,3,2,5,4,2,1,3,1,4,2,2,1,3,3,1};
User u2 = User("tony stark", testRate, 50);

cout << "getUsername() returned: " << u2.getUsername() << endl;
cout << "getNumRatings() returned: " << u2.getNumRatings() << endl;

cout << "u2.getRatingAt(0)  = " << u2.getRatingAt(0) << endl;
cout << "u2.getRatingAt(10) = " << u2.getRatingAt(10) << endl;
cout << "u2.getRatingAt(50) = " << u2.getRatingAt(50) << endl;
}