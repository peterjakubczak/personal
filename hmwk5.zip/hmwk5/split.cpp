#include <iostream>
#include <fstream>
#include <string>
using namespace std;



int split(string str, char c, string array[], int length){
    if(str == ""){ //If string is empty
        return 0;
    }
    int i = 0;
    if(str[0] == c){ //if string at 0 is equal to char c
        i = 1;
    }
    int length1 = str.length();
    int numStrings = 0;
    int arrayCount = 0;
    string x = "";
    char f;
    str += c; 
    while(i < length1 + 1){ //loop until size of string line
        string position = str.substr(i,1);
        f = str[i]; //add characters to word
        if((f != c) || (str[i+1] == c)){
            x += position;
        }
        else{
            numStrings ++;
            array[arrayCount] = x;
            x = "";
            arrayCount++; 
        }
    
       i++;
       }
       
     return numStrings;
    }
  
    


int main(){
    string d = "the,cat,dog";
    char b = ',';
    string w[3];
    int arrLength = 3;
    int numberStrings = split(d, b, w, arrLength);
    cout << "numberStrings: " << numberStrings << endl;
    cout << w[0] << endl << w[1] << endl << w[2] << endl;
}