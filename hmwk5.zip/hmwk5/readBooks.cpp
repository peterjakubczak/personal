//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Homework 5 - Problem 2
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**
 * Algorithim: that populates a pair of arrays with the titles and authors found in
books.txt.
 * 1. Call split function
 * 2. Open file and read each line of file, check too see if file is open, also check if stored books is less than size
 * 3. Populate the array
 * Input: Strings, char, and an int
 * Output: None
 * Return: Return number of books stored.
*/

int split(string str, char c, string array[], int length){
    if(str == ""){ //If string is empty
        return 0;
    }
    int i = 0;
    if(str[0] == c){ //if string at 0 is equal to char c
        i = 1;
    }
    int length1 = str.length();
    int numStrings = 0;
    int arrayCount = 0;
    string x = "";
    char f;
    str += c; 
    while(i < length1 + 1){ //loop until size of string line
        string position = str.substr(i,1);
        f = str[i]; //add characters to word
        if((f != c) || (str[i+1] == c)){
            x += position; //sets x to position
        }
        else{
            numStrings ++;
            array[arrayCount] = x;
            x = "";
            arrayCount++; 
        }
    
       i++;
       }
       
     return numStrings;
    }
  
int readBooks(string fileName, string arrayTitles[], string arrayAuthors[], int numBookStored, int size){
    ifstream myFile; //create an output file stream for writing to file
    myFile.open("books.txt"); //open books.txt
    if(numBookStored == size){ 
        return -2;
    }
    if (myFile.is_open()){
        string arrayTemp[size];
        string line = "";
        int lineidx = 0;
        while(getline(myFile, line)){
            if (numBookStored < size){ //if number of books stored is less than size
                break; //break loop
            }
            else if (line!=""){ //if lines not empty
                split(line, ',', arrayTemp, size);
                arrayAuthors[numBookStored] = arrayTemp[0]; //fills authors array
                arrayTitles[numBookStored] = arrayTemp[1]; //fills titles array
                 numBookStored++; //increase number of books stored
            }
          
        }
      return numBookStored;
    }
    else
    {
        return -1;
    }
}

int main(){
    string authors[10];
    string titles[10];
    readBooks("fileName.txt",titles,authors, 0, 10);
    cout << authors[4] << endl;
    cout << authors[5] << endl;
    cout << titles[1] << endl;
    cout << titles[2] << endl;

}




