//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Paricha
//Homework 5 - Problem 7
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**
 * Algorithim: that loads user ratings by reading the ratings.txt file
 * 1. Calling split function
 * 2. Open file, if number of users is equivalent to maximum number of rows, return -2
 * 3. Loop reads lines, split gets elements, next loop fills arrays
 * Input: String, character, array of string, int and ratings.txt
 * Output: None
 * Return: Number of users
*/

int split(string str, char c, string array[], int length){
    if(str == ""){ //If string is empty
        return 0;
    }
    int i = 0;
    if(str[0] == c){ //if string at 0 is equal to char c
        i = 1;
    }
    int length1 = str.length();
    int numStrings = 0;
    int arrayCount = 0;
    string x = "";
    char f;
    str += c; 
    while(i < length1 + 1){ //loop until size of string line
        string position = str.substr(i,1);
        f = str[i]; //add characters to word
        if((f != c) || (str[i+1] == c)){
            x += position;
        }
        else{
            numStrings ++;
            array[arrayCount] = x;
            x = "";
            arrayCount++; 
        }
    
       i++;
       }
       
     return numStrings;
    }
  
int readRatings(string file, string users[], int ratings[][50], int numUsers, int maxRow, int maxColumns){
    ifstream myFile;
    myFile.open(file);
    if(numUsers == maxRow){ //if number of users equals maximum number of rows, return -2
        return -2;
    }
    if (myFile.is_open()){
        string line;
        int i = 0;
        string array[51];
        while(getline(myFile, line) && (numUsers < maxRow)){
            if(line != ""){ //if lines not empty
                split(line, ',', array, 51 ); //gets elements
                users[numUsers] = array[0];
                int k = 1;
                for(k; k < maxColumns+1; k++){ //goes through each column
                    if(array[k] == ""){
                       break;
                       
                    }
                    else{
                        ratings[numUsers][k-1] = stoi(array[k]); //fills the array with elements
                    }
                }
              numUsers++;
            }
        }
      
    }
    else{
        return -1;
    }
  return numUsers;
}
int main(){
    string user1[10] = ();
    int ratings[10][50] = {{0}};
    int numUsers1 = 0;
    int maxRow1 = 10;
    int maxColumns1 = 50;
    readRatings("ratings.txt", user1, ratings, numUsers1, maxRow1, maxColumns1);
    
    string user1[8] = ();
    int ratings[8][42] = {{0}};
    int numUsers1 = 0;
    int maxRow1 = 8;
    int maxColumns1 = 42;
    readRatings("ratings.txt", user1, ratings, numUsers1, maxRow1, maxColumns1);
    
}