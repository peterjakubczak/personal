//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Paricha
//Homework 5 - Problem 6
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**
 * Algorithim: that reads from a text file, stores its contents in a 2D array,
and returns the number of lines it reads.
 * 1. Call split function
 * 2. Open the file, if it doesn't, then return -1
 * 3. Loop that reads each line, split function takes the line and makes it an array of elements
 * 4. Second loop that fills array with temp array from split
 * Input: Array, int, and double
 * Output: Map of water level
 * Return: none
*/

int split(string str, char c, string array[], int length){
    if(str == ""){ //If string is empty
        return 0;
    }
    int i = 0;
    if(str[0] == c){ //if string at 0 is equal to char c
        i = 1;
    }
    int length1 = str.length();
    int numStrings = 0;
    int arrayCount = 0;
    string x = "";
    char f;
    str += c; 
    while(i < length1 + 1){ //loop until size of string line
        string position = str.substr(i,1);
        f = str[i]; //add characters to word
        if((f != c) || (str[i+1] == c)){
            x += position;
        }
        else{
            numStrings ++;
            array[arrayCount] = x;
            x = "";
            arrayCount++; 
        }
    
       i++;
       }
       
     return numStrings;
    }
  
    

int readFloatMap(string file, double array[][4], int rows){
    ifstream myFile;
    myFile.open(file);
    string line; 
    int numberOfRows = 0;
    string arrayTemp[4];
    if(!(myFile.is_open())){ //if file doesn't open
        return -1;
    }
    else{
        while(getline(myFile,line)){ //read each line
            if(line != ""){
                split(line,',', arrayTemp,4); //array of elements
                int i = 0;
                while(i<4){
                    array[numberOfRows][i] = stof(arrayTemp[i]); //fills array with elements
                    i++;
                }
              numberOfRows++;
            }
            else{
                continue;
            }
        }
    }
    return numberOfRows;
}
int main(){
    double map[5][5];
    cout << readFloatMap("floodMap.txt",map, 5);
    double map[7][7];
    cout << readFloatMap("floodMap.txt",map, 7);
}