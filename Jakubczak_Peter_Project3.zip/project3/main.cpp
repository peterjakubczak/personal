//CS1300 Fall 2019
//Author: Peter Jakubczak
//Recitation: 104 Anuj Pasricha
//Project 3


/**
 * Algorithim: Creates main
   1. Runs the game
 * Input: Strings, ints, array
 * Output: None
 * Return: Depends per function
*/
#include <iostream>
#include <string>
using namespace std;


int main
{
     Pokemon allPokemon[151];
     int map[25][16];
     Game myGame();
     myGame.firstMenu();
     Map cart;
     cart.displayMap();
     return 0;
}